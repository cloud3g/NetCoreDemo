# NetCore
Just a bunch of code using following technologies:

- WebAPI with .Net Core
- EF Core
- SQL Server Azure
