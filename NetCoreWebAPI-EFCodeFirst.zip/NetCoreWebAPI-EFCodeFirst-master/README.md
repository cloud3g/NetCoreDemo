# NetCoreWebAPI-EFCodeFirst
Demo RESTfulAPI với ASP.NET Core và Entity Framework Code First
Apply Dependency Injection & Design Pattern: Repository