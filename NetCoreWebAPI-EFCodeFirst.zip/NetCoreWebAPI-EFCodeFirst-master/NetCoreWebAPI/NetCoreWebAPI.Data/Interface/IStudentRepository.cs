﻿using NetCoreWebAPI.Data.Infrastructure;
using NetCoreWebAPI.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCoreWebAPI.Data.Interface
{
    public interface IStudentRepository : IRepository<Student>
    {

    }
}
