﻿using Blog.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IService
{
    public partial interface IWC_OfficalAccountsService
    {
       Response SetDefault(int id);
    }
}
