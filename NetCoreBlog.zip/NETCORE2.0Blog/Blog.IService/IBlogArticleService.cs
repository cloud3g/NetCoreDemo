﻿
using Blog.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IService
{
    public interface IBlogArticleService:IService<BlogArticle>
    {
    }
}
