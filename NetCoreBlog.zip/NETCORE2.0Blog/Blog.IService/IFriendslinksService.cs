﻿using Blog.Common;
using Blog.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IService
{
    public interface IFriendslinksService:IService<Friendslinks>
    {
     
    }
}
