﻿using Blog.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IService
{
    public partial interface IWC_OfficalAccountsService : IService<WC_OfficalAccounts>
    {

    }
    public partial interface IWC_MessageResponseService : IService<WC_MessageResponse>
    {

    }
}
