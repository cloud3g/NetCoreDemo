# NETCORE2.0Blog
基于.NET Core 2.0开发的一个个人博客。

相关资源

01-阿里云服务器 centos7

02-项目相关

ASP.NET CORE 2 + EF CORE + postgresql 

网页框架layui:http://www.layui.com/

前台模板:http://www.lyblogs.cn/

后台模板：http://www.zjsoar.com/layuicms/

页面用到的treegrid:http://www.layuispa.com/


预览： http://101.201.236.115 后台：http://101.201.236.115/admin