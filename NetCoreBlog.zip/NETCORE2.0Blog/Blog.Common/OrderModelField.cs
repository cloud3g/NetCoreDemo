﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Common
{
    public struct OrderModelField
    {
        public string PropertyName { get; set; }
        public bool IsDESC { get; set; }
    }
}
