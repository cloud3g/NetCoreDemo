﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Models
{
    public class BlogSettings:Entity
    {
    }
}
