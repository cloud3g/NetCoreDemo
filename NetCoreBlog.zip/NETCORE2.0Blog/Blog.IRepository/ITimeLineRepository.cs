﻿using Blog.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IRepository
{
    public interface ITimeLineRepository : IRepository<TimeLine>
    {
    }
}
