﻿using Blog.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.IRepository
{
    public partial interface  IWC_OfficalAccountsRepository: IRepository<WC_OfficalAccounts>
    {

    }
    public partial interface IWC_MessageResponseRepository : IRepository<WC_MessageResponse>
    {

    }
}
